!!!!!DO NOT REBOOT MacBook after starting Script!!!!!
!!!!!DO NOT REBOOT AFTER INSTALLING BootCamp Drivers!!!!!